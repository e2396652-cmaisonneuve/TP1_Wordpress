<footer>
    <div class="global">
        <section class="footer__contact">
            <h2 class="footer__titre">Contact</h2>
            <p>numero</p>

        </section>
        section
    </div>
</footer>
<?php wp_footer(); ?>
</body>

</html>
