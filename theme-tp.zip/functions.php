<?php

function theme_tp_customize_register($wp_customize)
{
  // Le code pour ajouter des sections, des réglages et des contrôles ira ici.

  //Ajoute title dans la section hero
  $wp_customize->add_setting('hero_title', array(
    'default' => __('Bienvenue sur mon site', 'theme_tp'),
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('hero_title', array(
    'label' => __('Hero Title', 'theme_tp'),
    'section' => 'hero_section',
    'type' => 'text',
  ));

  //Ajoute description dans la section hero
  $wp_customize->add_setting('hero_description', array(
    'default' => __('Lorem ipsum', 'theme_tp'),
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('hero_description', array(
    'label' => __('Hero Description', 'theme_tp'),
    'section' => 'hero_section',
    'type' => 'text',
  ));


  //Ajoute du telephone dans la section hero

  $wp_customize->add_section('hero_telephone', array(
    'title' => __('Section Hero', 'theme_tp'),
    'priority' => 30,

  ));

  $wp_customize->add_setting('hero_telephone', array(
    'default' => __('514-123-4567', 'theme_tp'),
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('hero_telephone', array(
    'label' => __('Telephone', 'theme_tp'),
    'section' => 'hero_section',
    'type' => 'text',
  ));

  //Ajoute du email dans la section hero

  $wp_customize->add_section('hero_email', array(
    'title' => __('Section Hero', 'theme_tp'),
    'priority' => 30,

  ));

  $wp_customize->add_setting('hero_email', array(
    'default' => __('email@email.com', 'theme_tp'),
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('hero_email', array(
    'label' => __('E-mail', 'theme_tp'),
    'section' => 'hero_section',
    'type' => 'text',
  ));

  //Ajoute du address dans la section hero

  $wp_customize->add_section('hero_addresse', array(
    'title' => __('Section Hero', 'theme_tp'),
    'priority' => 30,

  ));

  $wp_customize->add_setting('hero_addresse', array(
    'default' => __('123 rue Lorem', 'theme_tp'),
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('hero_addresse', array(
    'label' => __('Addresse', 'theme_tp'),
    'section' => 'hero_section',
    'type' => 'text',
  ));

  //Ajoute du ville dans la section hero

  $wp_customize->add_section('hero_ville', array(
    'title' => __('Section Hero', 'theme_tp'),
    'priority' => 30,

  ));

  $wp_customize->add_setting('hero_ville', array(
    'default' => __('Montréal, QC H1H 1H1', 'theme_tp'),
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('hero_ville', array(
    'label' => __('Addresse', 'theme_tp'),
    'section' => 'hero_section',
    'type' => 'text',
  ));

  //Ajoute auteur dans la section hero
  $wp_customize->add_section('hero_section', array(
    'title' => __('Section Hero', 'theme_tp'),
    'priority' => 30,

  ));

  $wp_customize->add_setting('hero_auteur', array(
    'default' => __('Mariana Neri Matos', 'theme_tp'),
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_control('hero_auteur', array(
    'label' => __('Auteur', 'theme_tp'),
    'section' => 'hero_section',
    'type' => 'text',
  ));

  //Ajoute du CTA dans la section hero

  $wp_customize->add_setting('hero_cta_text', array(
    'default' => __('Learn More', 'theme_tp'),
    'sanitize_callback' => 'sanitize_text_field',
  ));

  $wp_customize->add_control('hero_cta_text', array(
    'label' => __('CTA Button Text', 'theme_tp'),
    'section' => 'hero_section',
    'type' => 'text',
  ));

  //Ajoute du background dans la section hero

  $wp_customize->add_setting('hero_background', array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
  ));

  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'hero_background', array(
    'label' => __('Hero Background Image', 'theme_tp'),
    'section' => 'hero_section',
  )));
}

add_action('customize_register', 'theme_tp_customize_register');

function mon_theme_supports()
{
  add_theme_support('title-tag');
  add_theme_support('menus');
  add_theme_support('post-thumbnails');
}
add_action('after_setup_theme', 'mon_theme_supports');




function theme_tp_enqueue_styles()
{
  wp_enqueue_style('normalize', get_template_directory_uri() . '/css/normalize.css');
  wp_enqueue_style(
    'main-styles',
    get_template_directory_uri() . '/style.css',
    array(),
    filemtime(get_template_directory() . '/style.css')
  );
}
add_action('wp_enqueue_scripts', 'theme_tp_enqueue_styles');

function new_excerpt_length($length)
{

  return 100;
}

add_filter('excerpt_length', 'new_excerpt_length');


/**
 * Modifie la requete principale de WordPress avant qu'elle soit exécuté
 * le hook « pre_get_posts » se manifeste juste avant d'exécuter la requête principal
 * Dépendant de la condition initiale on peut filtrer un type particulier de requête
 * Dans ce cas ci nous filtrons la requête de la page d'accueil
 * @param WP_query  $query la requête principal de WP
 */
function modifie_requete_principal($query)
{
  if ($query->is_home() && $query->is_main_query() && ! is_admin()) {
    $query->set('category_name', 'Populaire');
    $query->set('orderby', 'title');
    $query->set('order', 'ASC');
  }
}
add_action('pre_get_posts', 'modifie_requete_principal');

function ajout_options()
{
  // Activer le support des menus personnalisés
  add_theme_support('menus');
  add_theme_support('custom-logo', array(
    'height'      => 250,
    'width'       => 250,
    'flex-height' => true,
    'flex-width'  => true,
  ));
}
add_action('after_setup_theme', 'ajout_options');
