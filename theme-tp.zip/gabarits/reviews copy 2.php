<section class="testimonials-section">
    <div class="container">
        <div class="testimonials-carousel">
            <div class="carousel-track">
                <!-- Depoimento 1 -->
                <div class="testimonial">
                    <img src="https://gftnth00.mywhc.ca/33w10/wp-content/uploads/2025/03/avatar1.jpg" alt="Avatar do Cliente" class="testimonial-avatar">
                    <h3 class="client-name">Élodie Nkosi</h3>
                    <p class="client-review">"Expérience incroyable ! Je recommande vivement cette agence pour des aventures inoubliables."</p>
                </div>
                <!-- Depoimento 2 -->
                <div class="testimonial">
                    <img src="https://gftnth00.mywhc.ca/33w10/wp-content/uploads/2025/03/avatar2.jpg" alt="Avatar do Cliente" class="testimonial-avatar">
                    <h3 class="client-name">Gabriel Lefebvre</h3>
                    <p class="client-review">"Les meilleures vacances de ma vie ! Excellent service client et destinations uniques."</p>
                </div>
                <!-- Depoimento 3 -->
                <div class="testimonial">
                    <img src="https://gftnth00.mywhc.ca/33w10/wp-content/uploads/2025/03/avatar3.jpg" alt="Avatar do Cliente" class="testimonial-avatar">
                    <h3 class="client-name">Camille Dubois</h3>
                    <p class="client-review">"Des forfaits de voyage incroyables et un processus de réservation fluide. Je reviendrai sans aucun doute."</p>
                </div>
                <!-- Depoimento 4 -->
                <div class="testimonial">
                    <img src="https://gftnth00.mywhc.ca/33w10/wp-content/uploads/2025/03/avatar4.jpg" alt="Avatar do Cliente" class="testimonial-avatar">
                    <h3 class="client-name">Monique Gagnon</h3>
                    <p class="client-review">"Je me suis senti en confiance tout au long du processus. Une agence fiable et chaleureuse !"</p>
                </div>
                <!-- Depoimento 5 -->
                <div class="testimonial">
                    <img src="https://gftnth00.mywhc.ca/33w10/wp-content/uploads/2025/03/avatar5.jpg" alt="Avatar do Cliente" class="testimonial-avatar">
                    <h3 class="client-name">Alexandre Dupont</h3>
                    <p class="client-review">"Le service personnalisé, les conseillers attentifs et les options adaptées à mon budget ont fait toute la différence."</p>
                </div>
                <!-- Depoimento 6 -->
                <div class="testimonial">
                    <img src="https://gftnth00.mywhc.ca/33w10/wp-content/uploads/2025/03/avatar6.jpg" alt="Avatar do Cliente" class="testimonial-avatar">
                    <h3 class="client-name">Brigitte Lafleur</h3>
                    <p class="client-review">"Merci à cette agence pour un séjour familial inoubliable, bien organisé et adapté, offrant des moments précieux."</p>
                </div>
                <!-- Depoimento 7 -->
                <div class="testimonial">
                    <img src="https://gftnth00.mywhc.ca/33w10/wp-content/uploads/2025/03/avatar7.jpg" alt="Avatar do Cliente" class="testimonial-avatar">
                    <h3 class="client-name">Luc Lavoie</h3>
                    <p class="client-review">"Des conseils personnalisés et un suivi impeccable. Notre road trip en Gaspésie était inoubliable. Bravo !"</p>
                </div>
                <!-- Depoimento 8 -->
                <div class="testimonial">
                    <img src="https://gftnth00.mywhc.ca/33w10/wp-content/uploads/2025/03/avatar8.jpg" alt="Avatar do Cliente" class="testimonial-avatar">
                    <h3 class="client-name">Antoine Desjardins</h3>
                    <p class="client-review">"Tout était bien organisé, des billets aux conseils, pour une expérience incroyable et sans stress. À refaire !"</p>
                </div>

            </div>
        </div>
        <!-- Botões de Navegação do Carrossel -->
        <button class="carousel-button prev" aria-label="Anterior">&#10094;</button>
        <button class="carousel-button next" aria-label="Próximo">&#10095;</button>
    </div>
</section>